import { SideSwipeDirective } from './side-swipe.directive';

describe('SideSwipeDirective', () => {
  it('should create an instance', () => {
    const directive = new SideSwipeDirective();
    expect(directive).toBeTruthy();
  });
});
