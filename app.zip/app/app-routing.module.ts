import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [

  { path: '', loadChildren: './splash/splash.module#SplashPageModule' },
  { path: 'home', loadChildren: () => import('./home/home.module').then(m => m.HomePageModule) },

  {
    path: 'examples/full-screen',
    loadChildren: () => import('./slides/full-screen/full-screen.module').then( m => m.FullScreenPageModule)
  },
  {
    path: 'examples/scrollable',
    loadChildren: () => import('./slides/scrollable/scrollable.module').then( m => m.ScrollablePageModule)
  },

  { path: 'pdf', loadChildren: './pdf/pdf.module#PdfPageModule' },
  { path: 'facteurs', loadChildren: './facteurs/facteurs.module#FacteursPageModule' },
  { path: 'accueil', loadChildren: './accueil/accueil.module#AccueilPageModule' },
];
@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
