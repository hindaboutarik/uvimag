import { AfterViewInit, Component, ViewChild } from '@angular/core';
import { SuperTabs } from '@ionic-super-tabs/angular';
import { SuperTabsConfig } from '@ionic-super-tabs/core';
import { ContactsPage } from '../slides/slide1/slide1.page';
import { ProfilePage } from '../profile/profile.page';
import { Profile2Page } from '../slides/profile2/profile2.page';
import { Profile3Page } from '../slides/profile3/profile3.page';
import { Profile4Page } from '../slides/profile4/profile4.page';
import { Profile5Page } from '../slides/profile5/profile5.page';
import { Profile6Page } from '../slides/profile6/profile6.page';
import { Profile7Page } from '../slides/profile7/profile7.page';
import { Profile8Page } from '../slides/profile8/profile8.page';
import { Profile9Page } from '../slides/profile9/profile9.page';
import { Profile10Page } from '../slides/profile10/profile10.page';
import { Profile11Page } from '../slides/profile11/profile11.page';
import { Profile12Page } from '../slides/profile12/profile12.page';
import { AccueilPage } from '../accueil/accueil.page';

import { Routes, RouterModule } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage implements AfterViewInit {



  @ViewChild(SuperTabs) superTabs: SuperTabs;

  contactsPage = ContactsPage;
  profilePage = ProfilePage;
  profile2Page  = Profile2Page;
  profile3Page  = Profile3Page;
  profile4Page  = Profile4Page;
  profile5Page  = Profile5Page;
  profile6Page  = Profile6Page;
  profile7Page  = Profile7Page;
  profile8Page  = Profile8Page;
  profile9Page  = Profile9Page;
  profile10Page  = Profile10Page;
  profile11Page  = Profile11Page;
  profile12Page  = Profile12Page;
  accueilPage    = AccueilPage;
  opts = {
    icon: false,
    label: true,
    toolbarPos: 'top',
    scrollable: true,
  };

  config: SuperTabsConfig = {
    debug: true,
    allowElementScroll: false,
  };

  tabs: any[] = [];

  ngAfterViewInit() {
    console.log('Super tabs', this.superTabs);
    // this.superTabs.selectTab(1);
  }
  animateOnTabChange(e){
    
    console.log("animateOnTabChange")
    console.log(e)

    // example to animate tab with index=1
    if(e.detail.index == 0){
      document.getElementById('homme').classList.add("swirl-in-fwd");
      document.getElementById('homme1').classList.add("swirl-in-fwd0");
      document.getElementById('homme2').classList.add("swirl-in-fwd01");
      document.getElementById('mc').classList.remove("mc");
      document.getElementById('coeure').classList.remove("coeure");
      document.getElementById('umne').classList.remove("umne");
      document.getElementById('spe').classList.remove("spe");
      document.getElementById('crmpe').classList.remove("crmpe");
      document.getElementById('tol').classList.remove("tol");
      document.getElementById('ef').classList.remove("ef");
      document.getElementById('pos').classList.remove("pos");

      document.getElementById('tol1').classList.remove("tol1");
      document.getElementById('tol2').classList.remove("tol2");
      document.getElementById('tol3').classList.remove("tol3");
      document.getElementById('ligne1').classList.remove("ligne1");
      document.getElementById('ligne2').classList.remove("ligne2");
      document.getElementById('ligne3').classList.remove("ligne3");
      document.getElementById('ligne1b').classList.remove("ligne1b");
      document.getElementById('ligne2b').classList.remove("ligne2b");
      document.getElementById('ligne3b').classList.remove("ligne3b");
      document.getElementById('r1').classList.remove("r1");
      document.getElementById('r2').classList.remove("r2");
      document.getElementById('r3').classList.remove("r3");
      document.getElementById('gen1').classList.remove("gen1");
      document.getElementById('gen2').classList.remove("gen2");
      document.getElementById('gen3').classList.remove("gen3");
      document.getElementById('db').classList.remove("swirl-in-fwddb");
      document.getElementById('dbc').classList.remove("swirl-in-fwddbc");
      document.getElementById('do').classList.remove("swirl-in-fwddo");
      document.getElementById('doc').classList.remove("swirl-in-fwddoc");
      document.getElementById('nbr').classList.remove("swirl-in-fwdnbr");
      document.getElementById('gnbr').classList.remove("swirl-in-fwdgnbr");
      document.getElementById('bpolygon').classList.remove("swirl-in-fwdcb");
      document.getElementById('bpolygons').classList.remove("swirl-in-fwdcbs");
      document.getElementById('opolygon').classList.remove("swirl-in-fwdco");
      document.getElementById('opolygons').classList.remove("swirl-in-fwdcos");
      document.getElementById('fbleu').classList.remove("swirl-in-fwdfbleu");
      document.getElementById('forange').classList.remove("swirl-in-fwdforange");
      document.getElementById('db21').classList.remove("db21");
      document.getElementById('db2o2').classList.remove("db2o2");
      document.getElementById('db2c3').classList.remove("db2c3")
      document.getElementById('db2p4').classList.remove("db2p4");
      document.getElementById('db2pb5').classList.remove("db2pb5");
      document.getElementById('d96').classList.remove("d96");
      document.getElementById('d47').classList.remove("d47");
      document.getElementById('d40').classList.remove("d40");
      document.getElementById('d7').classList.remove("d7");
      document.getElementById('d7o').classList.remove("d7o");
      document.getElementById('ligne9').classList.remove("ligne9");
      document.getElementById('d96').classList.remove("d96");
      document.getElementById('t1').classList.remove("t1a");
      document.getElementById('l1').classList.remove("l1");
      document.getElementById('l2').classList.remove("l2");
      document.getElementById('l3').classList.remove("l3"); 
      
      document.getElementById('tf2').classList.remove("tf2");
      document.getElementById('desc').classList.remove("desc");
      document.getElementById('tmg').classList.remove("mg100");
      document.getElementById('jr').classList.remove("jr");
      document.getElementById('tdesc').classList.remove("tdesc");

    } 
    if(e.detail.index == 1){
      document.getElementById('tol1').classList.remove("tol1");
      document.getElementById('tol2').classList.remove("tol2");
      document.getElementById('tol3').classList.remove("tol3");
     document.getElementById('homme').classList.remove("swirl-in-fwd");
      document.getElementById('homme1').classList.remove("swirl-in-fwd0");
      document.getElementById('homme2').classList.remove("swirl-in-fwd01");
      
      document.getElementById('mc').classList.add("mc");
      document.getElementById('umne').classList.add("umne");
      document.getElementById('coeure').classList.add("coeure");
      document.getElementById('spe').classList.add("spe");
      document.getElementById('crmpe').classList.add("crmpe");
      document.getElementById('ligne1b').classList.remove("ligne1b");
      document.getElementById('ligne2b').classList.remove("ligne2b");
      document.getElementById('ligne3b').classList.remove("ligne3b");
      
      
      document.getElementById('homme1').classList.remove("swirl-in-fwd0");
      document.getElementById('homme2').classList.remove("swirl-in-fwd01");
      document.getElementById('tol').classList.remove("tol");
      document.getElementById('ef').classList.remove("ef");
      document.getElementById('pos').classList.remove("pos");
      document.getElementById('ligne1').classList.remove("ligne1");
      document.getElementById('ligne2').classList.remove("ligne2");
      document.getElementById('ligne3').classList.remove("ligne3");
      document.getElementById('r1').classList.remove("r1");
      document.getElementById('r2').classList.remove("r2");
      document.getElementById('r3').classList.remove("r3");

      document.getElementById('gen1').classList.remove("gen1");
      document.getElementById('gen2').classList.remove("gen2");
      document.getElementById('gen3').classList.remove("gen3");
      document.getElementById('db').classList.remove("swirl-in-fwddb");
      document.getElementById('dbc').classList.remove("swirl-in-fwddbc");
      document.getElementById('do').classList.remove("swirl-in-fwddo");
      document.getElementById('doc').classList.remove("swirl-in-fwddoc");
      document.getElementById('nbr').classList.remove("swirl-in-fwdnbr");
      document.getElementById('gnbr').classList.remove("swirl-in-fwdgnbr");
      document.getElementById('bpolygon').classList.remove("swirl-in-fwdcb");
      document.getElementById('bpolygons').classList.remove("swirl-in-fwdcbs");
      document.getElementById('opolygon').classList.remove("swirl-in-fwdco");
      document.getElementById('opolygons').classList.remove("swirl-in-fwdcos");
      document.getElementById('fbleu').classList.remove("swirl-in-fwdfbleu");
      document.getElementById('db21').classList.remove("db21");
      document.getElementById('db2o2').classList.remove("db2o2");
      document.getElementById('db2c3').classList.remove("db2c3")
      document.getElementById('db2p4').classList.remove("db2p4");
      document.getElementById('db2pb5').classList.remove("db2pb5");
      document.getElementById('forange').classList.remove("swirl-in-fwdforange");
      document.getElementById('d96').classList.remove("d96");
      document.getElementById('d47').classList.remove("d47");
      document.getElementById('d40').classList.remove("d40");
      document.getElementById('d7').classList.remove("d7");
      document.getElementById('d7o').classList.remove("d7o");
      document.getElementById('ligne9').classList.remove("ligne9");
      document.getElementById('d96').classList.remove("d96");
      document.getElementById('t1').classList.remove("t1a");
 
      
      document.getElementById('tf2').classList.remove("tf2");

      document.getElementById('tmg').classList.remove("mg100");
      document.getElementById('jr').classList.remove("jr");
      document.getElementById('desc').classList.remove("desc");
      document.getElementById('tdesc').classList.remove("tdesc");
      document.getElementById('l1').classList.remove("l1");
      document.getElementById('l2').classList.remove("l2");
      document.getElementById('l3').classList.remove("l3"); 
    } if(e.detail.index == 2){
      document.getElementById('l1').classList.remove("l1");
      document.getElementById('l2').classList.remove("l2");
      document.getElementById('l3').classList.remove("l3"); 
      document.getElementById('tol1').classList.remove("tol1");
      document.getElementById('tol2').classList.remove("tol2");
      document.getElementById('tol3').classList.remove("tol3");
      document.getElementById('ligne1').classList.remove("ligne1");
      document.getElementById('ligne2').classList.remove("ligne2");
      document.getElementById('ligne3').classList.remove("ligne3");
      document.getElementById('tol').classList.add("tol");
      document.getElementById('ef').classList.add("ef");
      document.getElementById('pos').classList.add("pos");
      document.getElementById('spe').classList.remove("spe");

      document.getElementById('coeure').classList.remove("coeure");
      document.getElementById('umne').classList.remove("umne");
      document.getElementById('homme').classList.remove("swirl-in-fwd");
      document.getElementById('homme1').classList.remove("swirl-in-fwd0");
      document.getElementById('homme2').classList.remove("swirl-in-fwd01");
      document.getElementById('mc').classList.remove("mc");
      document.getElementById('crmpe').classList.remove("crmpe");
      document.getElementById('ligne1b').classList.remove("ligne1b");
      document.getElementById('ligne2b').classList.remove("ligne2b");
      document.getElementById('ligne3b').classList.remove("ligne3b");
      document.getElementById('gen1').classList.remove("gen1");
      document.getElementById('gen2').classList.remove("gen2");
      document.getElementById('gen3').classList.remove("gen3");
      document.getElementById('r1').classList.remove("r1");
      document.getElementById('r2').classList.remove("r2");
      document.getElementById('r3').classList.remove("r3");
      document.getElementById('db').classList.remove("swirl-in-fwddb");
      document.getElementById('dbc').classList.remove("swirl-in-fwddbc");
      document.getElementById('do').classList.remove("swirl-in-fwddo");
      document.getElementById('doc').classList.remove("swirl-in-fwddoc");
      document.getElementById('nbr').classList.remove("swirl-in-fwdnbr");
      document.getElementById('gnbr').classList.remove("swirl-in-fwdgnbr");
      document.getElementById('bpolygon').classList.remove("swirl-in-fwdcb");
      document.getElementById('bpolygons').classList.remove("swirl-in-fwdcbs");
      document.getElementById('opolygon').classList.remove("swirl-in-fwdco");
      document.getElementById('opolygons').classList.remove("swirl-in-fwdcos");
      document.getElementById('fbleu').classList.remove("swirl-in-fwdfbleu");
      document.getElementById('db21').classList.remove("db21");
      document.getElementById('db2o2').classList.remove("db2o2");
      document.getElementById('db2c3').classList.remove("db2c3")
      document.getElementById('db2p4').classList.remove("db2p4");
      document.getElementById('db2pb5').classList.remove("db2pb5");
      document.getElementById('forange').classList.remove("swirl-in-fwdforange");
      document.getElementById('d96').classList.remove("d96");
      document.getElementById('d47').classList.remove("d47");
      document.getElementById('d40').classList.remove("d40");
      document.getElementById('d7').classList.remove("d7");
      document.getElementById('d7o').classList.remove("d7o");
      document.getElementById('ligne9').classList.remove("ligne9");
      document.getElementById('d96').classList.remove("d96");
      document.getElementById('t1').classList.remove("t1a");
 
      document.getElementById('desc').classList.remove("desc");

      document.getElementById('tf2').classList.remove("tf2");

      document.getElementById('tmg').classList.remove("mg100");
      document.getElementById('jr').classList.remove("jr");
      document.getElementById('tdesc').classList.remove("tdesc");

    } 
    if(e.detail.index == 3){
      document.getElementById('desc').classList.remove("desc");

      document.getElementById('spe').classList.remove("spe");
      document.getElementById('crmpe').classList.remove("crmpe");
      document.getElementById('umne').classList.remove("umne");
      document.getElementById('mc').classList.remove("mc");
      document.getElementById('coeure').classList.remove("coeure");
      document.getElementById('homme').classList.remove("swirl-in-fwd");
      document.getElementById('homme1').classList.remove("swirl-in-fwd0");
      document.getElementById('homme2').classList.remove("swirl-in-fwd01");
      document.getElementById('tol').classList.remove("tol");
      document.getElementById('ef').classList.remove("ef");
      document.getElementById('pos').classList.remove("pos");
      document.getElementById('tol1').classList.add("tol1");
      document.getElementById('tol2').classList.add("tol2");
      document.getElementById('tol3').classList.add("tol3");
     
      document.getElementById('ligne1').classList.add("ligne1");
      document.getElementById('ligne2').classList.add("ligne2");
      document.getElementById('ligne3').classList.add("ligne3");
      document.getElementById('ligne1b').classList.add("ligne1b");
      document.getElementById('ligne2b').classList.add("ligne2b");
      document.getElementById('ligne3b').classList.add("ligne3b");

      document.getElementById('gen1').classList.add("gen1");
      document.getElementById('gen2').classList.add("gen2");
      document.getElementById('gen3').classList.add("gen3");

      document.getElementById('r1').classList.add("r1");
      document.getElementById('r2').classList.add("r2");
      document.getElementById('r3').classList.add("r3");

      document.getElementById('db').classList.remove("swirl-in-fwddb");
      document.getElementById('dbc').classList.remove("swirl-in-fwddbc");
      document.getElementById('do').classList.remove("swirl-in-fwddo");
      document.getElementById('doc').classList.remove("swirl-in-fwddoc");
      document.getElementById('nbr').classList.remove("swirl-in-fwdnbr");
      document.getElementById('gnbr').classList.remove("swirl-in-fwdgnbr");
      document.getElementById('bpolygon').classList.remove("swirl-in-fwdcb");
      document.getElementById('bpolygons').classList.remove("swirl-in-fwdcbs");
      document.getElementById('opolygon').classList.remove("swirl-in-fwdco");
      document.getElementById('opolygons').classList.remove("swirl-in-fwdcos");
      document.getElementById('fbleu').classList.remove("swirl-in-fwdfbleu");
      document.getElementById('db21').classList.remove("db21");
      document.getElementById('db2o2').classList.remove("db2o2");
      document.getElementById('db2c3').classList.remove("db2c3")
      document.getElementById('db2p4').classList.remove("db2p4");
      document.getElementById('db2pb5').classList.remove("db2pb5");
      document.getElementById('forange').classList.remove("swirl-in-fwdforange");
      document.getElementById('d96').classList.remove("d96");
      document.getElementById('d47').classList.remove("d47");
      document.getElementById('d40').classList.remove("d40");
      document.getElementById('d7').classList.remove("d7");
      document.getElementById('d7o').classList.remove("d7o");
      document.getElementById('ligne9').classList.remove("ligne9");
      document.getElementById('d96').classList.remove("d96");
      document.getElementById('t1').classList.remove("t1a");
 
      
      document.getElementById('tf2').classList.remove("tf2");

      document.getElementById('tmg').classList.remove("mg100");
      document.getElementById('jr').classList.remove("jr");
      document.getElementById('tdesc').classList.remove("tdesc");
      document.getElementById('l1').classList.remove("l1");
      document.getElementById('l2').classList.remove("l2");
      document.getElementById('l3').classList.remove("l3"); 

    } 
    if(e.detail.index == 4){
      document.getElementById('tol1').classList.remove("tol1");
      document.getElementById('tol2').classList.remove("tol2");
      document.getElementById('tol3').classList.remove("tol3");
      document.getElementById('umne').classList.remove("umne");
      document.getElementById('coeure').classList.remove("coeure");
      document.getElementById('homme').classList.remove("swirl-in-fwd");
      document.getElementById('homme1').classList.remove("swirl-in-fwd0");
      document.getElementById('homme2').classList.remove("swirl-in-fwd01");
      document.getElementById('mc').classList.remove("mc");
      document.getElementById('spe').classList.add("spe");
      document.getElementById('crmpe').classList.remove("crmpe");
      document.getElementById('tol').classList.remove("tol");
      document.getElementById('ef').classList.remove("ef");
      document.getElementById('pos').classList.remove("pos");
      document.getElementById('ligne1').classList.remove("ligne1");
      document.getElementById('ligne2').classList.remove("ligne2");
      document.getElementById('ligne3').classList.remove("ligne3");
      document.getElementById('ligne1b').classList.remove("ligne1b");
      document.getElementById('ligne2b').classList.remove("ligne2b");
      document.getElementById('ligne3b').classList.remove("ligne3b");
      document.getElementById('r1').classList.remove("r1");
      document.getElementById('r2').classList.remove("r2");
      document.getElementById('r3').classList.remove("r3");
      document.getElementById('gen1').classList.remove("gen1");
      document.getElementById('gen2').classList.remove("gen2");
      document.getElementById('gen3').classList.remove("gen3");
      document.getElementById('db').classList.add("swirl-in-fwddb");
      document.getElementById('dbc').classList.add("swirl-in-fwddbc");
      document.getElementById('do').classList.add("swirl-in-fwddo");
      document.getElementById('doc').classList.add("swirl-in-fwddoc");
      document.getElementById('nbr').classList.add("swirl-in-fwdnbr");
      document.getElementById('gnbr').classList.add("swirl-in-fwdgnbr");
      document.getElementById('bpolygon').classList.add("swirl-in-fwdcb");
      document.getElementById('bpolygons').classList.add("swirl-in-fwdcbs");
      document.getElementById('opolygon').classList.add("swirl-in-fwdco");
      document.getElementById('opolygons').classList.add("swirl-in-fwdcos");
      document.getElementById('fbleu').classList.add("swirl-in-fwdfbleu");
      document.getElementById('forange').classList.add("swirl-in-fwdforange");

      document.getElementById('db21').classList.remove("db21");
      document.getElementById('db2o2').classList.remove("db2o2");
      document.getElementById('db2c3').classList.remove("db2c3")
      document.getElementById('db2p4').classList.remove("db2p4");
      document.getElementById('db2pb5').classList.remove("db2pb5");
      document.getElementById('d96').classList.remove("d96");
      document.getElementById('d47').classList.remove("d47");
      document.getElementById('d40').classList.remove("d40");
      document.getElementById('d7').classList.remove("d7");
      document.getElementById('d7o').classList.remove("d7o");
      document.getElementById('ligne9').classList.remove("ligne9");
      document.getElementById('d96').classList.remove("d96");
      document.getElementById('t1').classList.remove("t1a");
 
      
      document.getElementById('tf2').classList.remove("tf2");
      document.getElementById('desc').classList.remove("desc");

      document.getElementById('tmg').classList.remove("mg100");
      document.getElementById('jr').classList.remove("jr");
      document.getElementById('tdesc').classList.remove("tdesc");
      document.getElementById('l1').classList.remove("l1");
      document.getElementById('l2').classList.remove("l2");
      document.getElementById('l3').classList.remove("l3"); 

    }
    if(e.detail.index == 5){
      document.getElementById('db').classList.remove("swirl-in-fwddb");
      document.getElementById('dbc').classList.remove("swirl-in-fwddbc");
      document.getElementById('do').classList.remove("swirl-in-fwddo");
      document.getElementById('doc').classList.remove("swirl-in-fwddoc");
      document.getElementById('nbr').classList.remove("swirl-in-fwdnbr");
      document.getElementById('gnbr').classList.remove("swirl-in-fwdgnbr");
      document.getElementById('bpolygon').classList.remove("swirl-in-fwdcb");
      document.getElementById('bpolygons').classList.remove("swirl-in-fwdcbs");
      document.getElementById('opolygon').classList.remove("swirl-in-fwdco");
      document.getElementById('opolygons').classList.remove("swirl-in-fwdcos");
      document.getElementById('fbleu').classList.remove("swirl-in-fwdfbleu");
      document.getElementById('forange').classList.remove("swirl-in-fwdforange");
      document.getElementById('desc').classList.remove("desc");

      document.getElementById('ligne1').classList.remove("ligne1");
      document.getElementById('ligne2').classList.remove("ligne2");
      document.getElementById('ligne3').classList.remove("ligne3");
      document.getElementById('tol1').classList.remove("tol1");
      document.getElementById('tol2').classList.remove("tol2");
      document.getElementById('tol3').classList.remove("tol3");
      document.getElementById('umne').classList.remove("umne");
      document.getElementById('homme').classList.remove("swirl-in-fwd");
      document.getElementById('homme1').classList.remove("swirl-in-fwd0");
      document.getElementById('homme2').classList.remove("swirl-in-fwd01");
      document.getElementById('mc').classList.remove("mc");
      document.getElementById('spe').classList.remove("spe");
      document.getElementById('crmpe').classList.remove("crmpe");
      document.getElementById('tol').classList.remove("tol");
      document.getElementById('ef').classList.remove("ef");
      document.getElementById('pos').classList.remove("pos");
      document.getElementById('ligne1b').classList.remove("ligne1b");
      document.getElementById('ligne2b').classList.remove("ligne2b");
      document.getElementById('ligne3b').classList.remove("ligne3b");
      document.getElementById('r1').classList.remove("r1");
      document.getElementById('r2').classList.remove("r2");
      document.getElementById('r3').classList.remove("r3");
      document.getElementById('gen1').classList.remove("gen1");
      document.getElementById('gen2').classList.remove("gen2");
      document.getElementById('gen3').classList.remove("gen3");

      document.getElementById('db21').classList.add("db21");
      document.getElementById('db2o2').classList.add("db2o2");
      document.getElementById('db2c3').classList.add("db2c3")
      document.getElementById('db2p4').classList.add("db2p4");
      document.getElementById('db2pb5').classList.add("db2pb5");
      document.getElementById('d96').classList.add("d96");
      document.getElementById('d47').classList.add("d47");
      document.getElementById('d40').classList.add("d40");
      document.getElementById('d7').classList.add("d7");
      document.getElementById('d7o').classList.add("d7o");
      document.getElementById('ligne9').classList.add("ligne9");
      document.getElementById('d96').classList.add("d96");

      document.getElementById('t1').classList.remove("t1a");
 
      
      document.getElementById('tf2').classList.remove("tf2");

      document.getElementById('tmg').classList.remove("mg100");
      document.getElementById('jr').classList.remove("jr");
      document.getElementById('tdesc').classList.remove("tdesc");

      document.getElementById('l1').classList.remove("l1");
      document.getElementById('l2').classList.remove("l2");
      document.getElementById('l3').classList.remove("l3"); 

    }
    if(e.detail.index == 6){
      document.getElementById('db21').classList.remove("db21");
      document.getElementById('db2o2').classList.remove("db2o2");
      document.getElementById('db2c3').classList.remove("db2c3")
      document.getElementById('db2p4').classList.remove("db2p4");
      document.getElementById('db2pb5').classList.remove("db2pb5");
      document.getElementById('d96').classList.remove("d96");
      document.getElementById('d47').classList.remove("d47");
      document.getElementById('d40').classList.remove("d40");
      document.getElementById('d7').classList.remove("d7");
      document.getElementById('d7o').classList.remove("d7o");
      document.getElementById('ligne9').classList.remove("ligne9");
      document.getElementById('d96').classList.remove("d96");
      document.getElementById('desc').classList.add("desc");
      document.getElementById('tdesc').classList.add("tdesc");

      document.getElementById('db').classList.remove("swirl-in-fwddb");
      document.getElementById('dbc').classList.remove("swirl-in-fwddbc");
      document.getElementById('do').classList.remove("swirl-in-fwddo");
      document.getElementById('doc').classList.remove("swirl-in-fwddoc");
      document.getElementById('nbr').classList.remove("swirl-in-fwdnbr");
      document.getElementById('gnbr').classList.remove("swirl-in-fwdgnbr");
      document.getElementById('bpolygon').classList.remove("swirl-in-fwdcb");
      document.getElementById('bpolygons').classList.remove("swirl-in-fwdcbs");
      document.getElementById('opolygon').classList.remove("swirl-in-fwdco");
      document.getElementById('opolygons').classList.remove("swirl-in-fwdcos");
      document.getElementById('fbleu').classList.remove("swirl-in-fwdfbleu");
      document.getElementById('forange').classList.remove("swirl-in-fwdforange");

      document.getElementById('tol1').classList.remove("tol1");
      document.getElementById('tol2').classList.remove("tol2");
      document.getElementById('tol3').classList.remove("tol3");
      document.getElementById('spe').classList.remove("spe");

      document.getElementById('umne').classList.remove("umne");
      document.getElementById('homme').classList.remove("swirl-in-fwd");
      document.getElementById('homme1').classList.remove("swirl-in-fwd0");
      document.getElementById('homme2').classList.remove("swirl-in-fwd01");
      document.getElementById('mc').classList.remove("mc");      
      document.getElementById('crmpe').classList.remove("crmpe");
      document.getElementById('tol').classList.remove("tol");
      document.getElementById('ef').classList.remove("ef");
      document.getElementById('pos').classList.remove("pos");

      document.getElementById('ligne1').classList.remove("ligne1");
      document.getElementById('ligne2').classList.remove("ligne2");
      document.getElementById('ligne3').classList.remove("ligne3");

      document.getElementById('ligne1b').classList.remove("ligne1b");
      document.getElementById('ligne2b').classList.remove("ligne2b");
      document.getElementById('ligne3b').classList.remove("ligne3b");
      document.getElementById('r1').classList.remove("r1");
      document.getElementById('r2').classList.remove("r2");
      document.getElementById('r3').classList.remove("r3");

      document.getElementById('gen1').classList.remove("gen1");
      document.getElementById('gen2').classList.remove("gen2");
      document.getElementById('gen3').classList.remove("gen3");

      document.getElementById('t1').classList.add("t1a");
      document.getElementById('jr').classList.add("jr");

      
      document.getElementById('tf2').classList.add("tf2");

      document.getElementById('tmg').classList.add("mg100");

      document.getElementById('l1').classList.remove("l1");
      document.getElementById('l2').classList.remove("l2");
      document.getElementById('l3').classList.remove("l3");     
    }    

    if(e.detail.index == 7){
      document.getElementById('db21').classList.remove("db21");
      document.getElementById('db2o2').classList.remove("db2o2");
      document.getElementById('db2c3').classList.remove("db2c3")
      document.getElementById('db2p4').classList.remove("db2p4");
      document.getElementById('db2pb5').classList.remove("db2pb5");
      document.getElementById('d96').classList.remove("d96");
      document.getElementById('d47').classList.remove("d47");
      document.getElementById('d40').classList.remove("d40");
      document.getElementById('d7').classList.remove("d7");
      document.getElementById('d7o').classList.remove("d7o");
      document.getElementById('ligne9').classList.remove("ligne9");
      document.getElementById('d96').classList.remove("d96");
      document.getElementById('desc').classList.remove("desc");
      document.getElementById('tdesc').classList.remove("tdesc");
      document.getElementById('l1').classList.add("l1");
      document.getElementById('l2').classList.add("l2");
      document.getElementById('l3').classList.add("l3");
      document.getElementById('db').classList.remove("swirl-in-fwddb");
      document.getElementById('dbc').classList.remove("swirl-in-fwddbc");
      document.getElementById('do').classList.remove("swirl-in-fwddo");
      document.getElementById('doc').classList.remove("swirl-in-fwddoc");
      document.getElementById('nbr').classList.remove("swirl-in-fwdnbr");
      document.getElementById('gnbr').classList.remove("swirl-in-fwdgnbr");
      document.getElementById('bpolygon').classList.remove("swirl-in-fwdcb");
      document.getElementById('bpolygons').classList.remove("swirl-in-fwdcbs");
      document.getElementById('opolygon').classList.remove("swirl-in-fwdco");
      document.getElementById('opolygons').classList.remove("swirl-in-fwdcos");
      document.getElementById('fbleu').classList.remove("swirl-in-fwdfbleu");
      document.getElementById('forange').classList.remove("swirl-in-fwdforange");

      document.getElementById('tol1').classList.remove("tol1");
      document.getElementById('tol2').classList.remove("tol2");
      document.getElementById('tol3').classList.remove("tol3");
      document.getElementById('spe').classList.remove("spe");

      document.getElementById('umne').classList.remove("umne");
      document.getElementById('homme').classList.remove("swirl-in-fwd");
      document.getElementById('homme1').classList.remove("swirl-in-fwd0");
      document.getElementById('homme2').classList.remove("swirl-in-fwd01");
      document.getElementById('mc').classList.remove("mc");      
      document.getElementById('crmpe').classList.remove("crmpe");
      document.getElementById('tol').classList.remove("tol");
      document.getElementById('ef').classList.remove("ef");
      document.getElementById('pos').classList.remove("pos");

      document.getElementById('ligne1').classList.remove("ligne1");
      document.getElementById('ligne2').classList.remove("ligne2");
      document.getElementById('ligne3').classList.remove("ligne3");

      document.getElementById('ligne1b').classList.remove("ligne1b");
      document.getElementById('ligne2b').classList.remove("ligne2b");
      document.getElementById('ligne3b').classList.remove("ligne3b");
      document.getElementById('r1').classList.remove("r1");
      document.getElementById('r2').classList.remove("r2");
      document.getElementById('r3').classList.remove("r3");

      document.getElementById('gen1').classList.remove("gen1");
      document.getElementById('gen2').classList.remove("gen2");
      document.getElementById('gen3').classList.remove("gen3");

      document.getElementById('t1').classList.remove("t1a");
      document.getElementById('jr').classList.remove("jr");

      
      document.getElementById('tf2').classList.remove("tf2");

      document.getElementById('tmg').classList.remove("mg100");
     
    }  
  // u can do that for every tab like in above .....


  }
  goToTab2(){
    this.superTabs.selectTab(1);
  }

  goToTab(index) {
    this.superTabs.selectTab(index);
  }
}
