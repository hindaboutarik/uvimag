import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import {HomePage} from './home.page';
const routes: Routes = [
    {
      path: 'home',
      component: HomePage,
      children: [
        {
          path: 'profile',
          children: [
            {
              path: '',
              loadChildren: () => import('../profile/profile.module').then( m => m.ProfilePageModule)
            }
          ]
        },
        {
          path: 'profile2',
          children: [
            {
              path: '',
              loadChildren: () => import('../slides/profile2/profile2.module').then( m => m.Profile2PageModule)
            }
          ]
        },
        {
          path: 'profile3',
          children: [
            {
              path: '',
              loadChildren: () => import('../slides/profile3/profile3.module').then( m => m.Profile3PageModule)
            }
          ]
        }
      ]
    },
    {
      path: '',
      redirectTo: '/home/profile',
      pathMatch: 'full'
    }
  ];
  @NgModule({
    imports: [
      RouterModule.forRoot(routes, { })
    ],
    exports: [RouterModule]
  })
  export class AppRoutingModule { }