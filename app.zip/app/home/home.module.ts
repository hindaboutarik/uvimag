import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { SuperTabsModule } from '@ionic-super-tabs/angular';
import { IonicModule } from '@ionic/angular';
import { PreferencesModule } from '../components/preferences/preferences.module';
import { ContactsPageModule } from '../slides/slide1/slide1.module';
import { ProfilePageModule } from '../profile/profile.module';
import { Profile2PageModule } from '../slides/profile2/profile2.module';
import { Profile3PageModule } from '../slides/profile3/profile3.module';
import { Profile4PageModule } from '../slides/profile4/profile4.module';
import { Profile5PageModule } from '../slides/profile5/profile5.module';
import { Profile6PageModule } from '../slides/profile6/profile6.module';
import { Profile7PageModule } from '../slides/profile7/profile7.module';
import { Profile8PageModule } from '../slides/profile8/profile8.module';
import { Profile9PageModule } from '../slides/profile9/profile9.module';
import { Profile10PageModule } from '../slides/profile10/profile10.module';
import { Profile11PageModule } from '../slides/profile11/profile11.module';
import { Profile12PageModule } from '../slides/profile12/profile12.module';
import { AccueilPage } from '../accueil/accueil.page';

import { Routes, } from '@angular/router';


import { HomePage } from './home.page';
import { AccueilPageModule } from '../accueil/accueil.module';

@NgModule({
  imports: [
    CommonModule,
    SuperTabsModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild([
      {
        path: '',
        component: HomePage,
      },
      
    ]),
    ContactsPageModule, ProfilePageModule,
    Profile2PageModule,
    Profile3PageModule,
    Profile4PageModule,
    Profile5PageModule,
    Profile6PageModule,
    Profile7PageModule,
    Profile8PageModule,
    Profile9PageModule,
    Profile10PageModule,
    Profile11PageModule,
    Profile12PageModule,
    AccueilPageModule,
   
    PreferencesModule,
    
    
  ],
  declarations: [HomePage],
})
export class HomePageModule {
}
