import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-splash1',
  templateUrl: './splash1.page.html',
  styleUrls: ['./splash1.page.scss'],
})
export class Splash1Page implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  setTimeout(() => {
      
    this.router.navigateByUrl("/home");

  }, 10000); 
  }

}
