import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-facteurs',
  templateUrl: './facteurs.page.html',
  styleUrls: ['./facteurs.page.scss'],
})
export class FacteursPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
