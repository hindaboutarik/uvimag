import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { FacteursPage } from './facteurs.page';
import { SideSwipeDirective } from "../side-swipe.directive";

const routes: Routes = [
  {
    path: '',
    component: FacteursPage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes),
    SideSwipeDirective
  ],
  declarations: [FacteursPage]
})
export class FacteursPageModule {}
