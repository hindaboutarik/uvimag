import { AfterViewInit, Directive, ElementRef, EventEmitter, Output, Renderer2 } from '@angular/core';
import { SWIPE_DIRECTION } from "../app/constants/constants";

@Directive({
  selector: '[appSideSwipe]'
})
export class SideSwipeDirective implements AfterViewInit {

  @Output() swipeLeft: EventEmitter<any>;
  @Output() swipeRight: EventEmitter<any>;

  constructor(private renderer: Renderer2,public elRef: ElementRef) {
    this.swipeRight = new EventEmitter<any>();
    this.swipeLeft = new EventEmitter<any>();
  }

  ngAfterViewInit() {
    this.renderer.listen(this.elRef.nativeElement, 'swipeend', (event: any) => {
      if (event.direction === SWIPE_DIRECTION.rightToLeft) {
        this.swipeLeft.emit();
      } else {
        this.swipeRight.emit();
      }
    });
  }


}
