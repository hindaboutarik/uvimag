import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SuperTabs } from '@ionic-super-tabs/angular';

@Component({
  selector: 'app-accueil',
  templateUrl: './accueil.page.html',
  styleUrls: ['./accueil.page.scss'],
})
export class AccueilPage implements OnInit {

  constructor(private router: Router,public superTabs: SuperTabs) { }
  isShownl: boolean = false ;
  isShownl2: boolean = false ;
  isShownl3: boolean = false ;
  ngOnInit() {
  }
  OpenLink(){
    this.router.navigateByUrl('/');

    }
  
    OpenPage(){
      this.router.navigateByUrl('/home');
  
      }

         // hidden by default
    
    
        toggleShowl() {
        
        this.isShownl = ! this.isShownl;
        
        }
        toggleShowl2() {
        
          this.isShownl2 = ! this.isShownl2;
          
          }
          toggleShowl3() {
        
            this.isShownl3 = ! this.isShownl3;
            
            }
        
         // hidden by default
    
    
    click() {
      this.isShownl = ! this.isShownl;
    }
    click2() {
      this.isShownl2 = ! this.isShownl2;
    }
    click3() {
      this.isShownl3 = ! this.isShownl3;
    }
  
    
}
