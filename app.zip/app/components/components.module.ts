import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { P1Component } from "./p1/p1.component";
import { IonicModule } from '@ionic/angular';
import { P2Component } from './p2/p2.component';
import { MedicamentComponent } from './combinaison/medicament/medicament.component';
const PAGES = [
  P1Component,
  P2Component,
  MedicamentComponent
]
@NgModule({
  declarations: PAGES,
  exports: PAGES,
  imports: [
    IonicModule,
    CommonModule
  ]
})
export class ComponentsModule { }
