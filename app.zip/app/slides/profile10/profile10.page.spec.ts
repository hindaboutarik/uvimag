import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Profile10Page } from './profile10.page';

describe('ProfilePage', () => {
  let component: Profile10Page;
  let fixture: ComponentFixture<Profile10Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Profile10Page ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Profile10Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
