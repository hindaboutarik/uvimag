import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile10',
  templateUrl: './profile10.page.html',
  styleUrls: ['./profile10.page.scss'],
})
export class Profile10Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
