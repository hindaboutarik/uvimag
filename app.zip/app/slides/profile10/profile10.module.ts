import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { Profile10Page } from './profile10.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
  ],
  declarations: [Profile10Page],
  exports: [Profile10Page],
  entryComponents: [Profile10Page],
})
export class Profile10PageModule {
}
