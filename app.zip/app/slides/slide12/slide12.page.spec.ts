import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Slide12Page } from './slide12.page';

describe('Slide12Page', () => {
  let component: Slide12Page;
  let fixture: ComponentFixture<Slide12Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Slide12Page ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Slide12Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
