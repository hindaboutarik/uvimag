import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-slide12',
  templateUrl: './slide12.page.html',
  styleUrls: ['./slide12.page.scss'],
})
export class Slide12Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
