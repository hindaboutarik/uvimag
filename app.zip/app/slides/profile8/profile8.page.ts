import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SuperTabs } from '@ionic-super-tabs/angular';

@Component({
  selector: 'app-profile8',
  templateUrl: './profile8.page.html',
  styleUrls: ['./profile8.page.scss'],
})
export class Profile8Page implements OnInit {
  isShownl: boolean = false ;
  isShownl0: boolean = false ;
  isShownl2: boolean = false ;
  isShownl3: boolean = false ;
  isShownl4: boolean = false ;
  constructor(private router: Router,public superTabs: SuperTabs) { }

  ngOnInit() {
  }
  OpenLink(){
    this.router.navigateByUrl('/');

    }
    toggleShowl() {
        
      this.isShownl = ! this.isShownl;
      
      }
      toggleShowl0() {
      
        this.isShownl0 = ! this.isShownl0;
        
        }
      toggleShowl2() {
        this.isShownl2 = ! this.isShownl2;
      }
      toggleShowl3() {
        this.isShownl3 = ! this.isShownl3;
      }
      toggleShowl4() {
        this.isShownl4 = ! this.isShownl4;
      }
       // hidden by default
  
  
  click() {
    this.isShownl = ! this.isShownl;
  }click0() {
    this.isShownl0 = ! this.isShownl0;
  }
  click2() {
    this.isShownl2 = ! this.isShownl2;
  }
  click3() {
    this.isShownl3 = ! this.isShownl3;
  }
}
