import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { Profile8Page } from './profile8.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
  ],
  declarations: [Profile8Page],
  exports: [Profile8Page],
  entryComponents: [Profile8Page],
})
export class Profile8PageModule {
}
