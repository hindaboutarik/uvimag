import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Slide3Page } from './slide3.page';

describe('Slide3Page', () => {
  let component: Slide3Page;
  let fixture: ComponentFixture<Slide3Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Slide3Page ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Slide3Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
