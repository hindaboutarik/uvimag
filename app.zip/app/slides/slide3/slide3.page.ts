import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-slide3',
  templateUrl: './slide3.page.html',
  styleUrls: ['./slide3.page.scss'],
})
export class Slide3Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
