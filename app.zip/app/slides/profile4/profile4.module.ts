import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { Profile4Page } from './profile4.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
  ],
  declarations: [Profile4Page],
  exports: [Profile4Page],
  entryComponents: [Profile4Page],
})
export class Profile4PageModule {
}
