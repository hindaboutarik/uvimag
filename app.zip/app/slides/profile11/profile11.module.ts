import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { Profile11Page } from './profile11.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
  ],
  declarations: [Profile11Page],
  exports: [Profile11Page],
  entryComponents: [Profile11Page],
})
export class Profile11PageModule {
}
