import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Profile11Page } from './profile11.page';

describe('ProfilePage', () => {
  let component: Profile11Page;
  let fixture: ComponentFixture<Profile11Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Profile11Page ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Profile11Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
