import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile11',
  templateUrl: './profile11.page.html',
  styleUrls: ['./profile11.page.scss'],
})
export class Profile11Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
