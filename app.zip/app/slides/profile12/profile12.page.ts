import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile12',
  templateUrl: './profile12.page.html',
  styleUrls: ['./profile12.page.scss'],
})
export class Profile12Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
