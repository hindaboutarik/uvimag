import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { Profile12Page } from './profile12.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
  ],
  declarations: [Profile12Page],
  exports: [Profile12Page],
  entryComponents: [Profile12Page],
})
export class Profile12PageModule {
}
