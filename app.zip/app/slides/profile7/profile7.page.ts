import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SuperTabs } from '@ionic-super-tabs/angular';

@Component({
  selector: 'app-profile7',
  templateUrl: './profile7.page.html',
  styleUrls: ['./profile7.page.scss'],
})
export class Profile7Page implements OnInit {

  constructor(private router: Router,public superTabs: SuperTabs) { }
  isShownl: boolean = false ;
  isShownl0: boolean = false ;
  isShownl2: boolean = false ;
  isShownl3: boolean = false ;
  isShownl4: boolean = false ;
  ngOnInit() {
  }
  OpenLink(){
    this.router.navigateByUrl('/');

    }
     // hidden by default


     toggleShowl() {
        
      this.isShownl = ! this.isShownl;
      
      }
      toggleShowl0() {
      
        this.isShownl0 = ! this.isShownl0;
        
        }
      toggleShowl2() {
        this.isShownl2 = ! this.isShownl2;
      }
      toggleShowl3() {
        this.isShownl3 = ! this.isShownl3;
      }
      toggleShowl4() {
        this.isShownl4 = ! this.isShownl4;
      }
       // hidden by default
  
  
  click() {
    this.isShownl = ! this.isShownl;
  }click0() {
    this.isShownl0 = ! this.isShownl0;
  }
  click2() {
    this.isShownl2 = ! this.isShownl2;
  }
  click3() {
    this.isShownl3 = ! this.isShownl3;
  }
  click4() {
    this.isShownl4 = ! this.isShownl4;
  }
}


