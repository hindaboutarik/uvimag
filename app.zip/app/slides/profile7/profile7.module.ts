import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { Profile7Page } from './profile7.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
  ],
  declarations: [Profile7Page],
  exports: [Profile7Page],
  entryComponents: [Profile7Page],
})
export class Profile7PageModule {
}
