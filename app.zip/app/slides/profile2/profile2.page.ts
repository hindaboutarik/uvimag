import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SuperTabs } from '@ionic-super-tabs/angular';

@Component({
  selector: 'app-profile2',
  templateUrl: './profile2.page.html',
  styleUrls: ['./profile2.page.scss'],
})
export class Profile2Page implements OnInit {

  constructor(private router: Router,public superTabs: SuperTabs) { }
  isShownl0: boolean = false ;
  isShownl: boolean = false ;
  isShownl1: boolean = false ;
  isShownl2: boolean = false ;
  isShownl3: boolean = false ;
  ngOnInit() {
  }
 
  OpenLink(){
    this.router.navigateByUrl('/');

    }
    OpenPage(){
      this.router.navigateByUrl('profile2');
  
      }
      openDetails() {
        // Both of these would work!
        // But the standard Router is recommended.
        // this.navController.navigateForward(`/tabs/films/42`);
        this.router.navigateByUrl(`/home/profile2`);
      }
      toggleShowl0() {
        
        this.isShownl0 = ! this.isShownl0;
        
        }
      toggleShowl() {
        
        this.isShownl = ! this.isShownl;
        
        }
        openTolerance() {
          this.isShownl1 = ! this.isShownl1;
        }
        toggleShowl2() {
          this.isShownl2 = ! this.isShownl3;
        }
         // hidden by default
    
         click0() {
          this.isShownl0 = ! this.isShownl0;
        }
    click() {
      this.isShownl = ! this.isShownl;
    }
    click2() {
      this.isShownl2 = ! this.isShownl2;
    }
    click3() {
      this.isShownl3 = ! this.isShownl3;
    }
  
}