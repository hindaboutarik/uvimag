import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { Profile2Page } from './profile2.page';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: 'profile2',
    component: Profile2Page
  }
];
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
  ],
  declarations: [Profile2Page],
  exports: [Profile2Page],
  entryComponents: [Profile2Page],
})
export class Profile2PageModule {
}
