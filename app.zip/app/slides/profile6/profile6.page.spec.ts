import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Profile6Page } from './profile6.page';

describe('ProfilePage', () => {
  let component: Profile6Page;
  let fixture: ComponentFixture<Profile6Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Profile6Page ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Profile6Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
