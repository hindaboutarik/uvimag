import { Component, OnInit } from '@angular/core';
import { SuperTabs } from '@ionic-super-tabs/angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-profile6',
  templateUrl: './profile6.page.html',
  styleUrls: ['./profile6.page.scss'],
})
export class Profile6Page implements OnInit {

  constructor(private router: Router,public superTabs: SuperTabs) { }
  isShownl: boolean = false ;
  isShownl0: boolean = false ;
  isShownl2: boolean = false ;
  isShownl3: boolean = false ;
  isShownl4: boolean = false ;

  ngOnInit() {
  }
  OpenLink(){
    this.router.navigateByUrl('/');

    }
    toggleShowl() {
        
      this.isShownl = ! this.isShownl;
      
      }
      toggleShowl0() {
      
        this.isShownl0 = ! this.isShownl0;
        
        }
      toggleShowl2() {
        this.isShownl2 = ! this.isShownl2;
      }
      toggleShowl3() {
        this.isShownl3 = ! this.isShownl3;
      }
      toggleShowl4() {
        this.isShownl4 = ! this.isShownl4;
      }
       // hidden by default
  
  
  click() {
    this.isShownl = ! this.isShownl;
  }click0() {
    this.isShownl0 = ! this.isShownl0;
  }
  click2() {
    this.isShownl2 = ! this.isShownl2;
  }
  click3() {
    this.isShownl3 = ! this.isShownl3;
  }
  click4() {
    this.isShownl4= ! this.isShownl4;
  }
}
