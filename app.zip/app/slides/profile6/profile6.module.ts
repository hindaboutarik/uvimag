import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { Profile6Page } from './profile6.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
  ],
  declarations: [Profile6Page],
  exports: [Profile6Page],
  entryComponents: [Profile6Page],
})
export class Profile6PageModule {
}
