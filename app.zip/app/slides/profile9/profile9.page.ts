import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile9',
  templateUrl: './profile9.page.html',
  styleUrls: ['./profile9.page.scss'],
})
export class Profile9Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
