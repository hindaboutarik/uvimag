import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Profile9Page } from './profile9.page';

describe('ProfilePage', () => {
  let component: Profile9Page;
  let fixture: ComponentFixture<Profile9Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Profile9Page ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Profile9Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
