import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { Profile9Page } from './profile9.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
  ],
  declarations: [Profile9Page],
  exports: [Profile9Page],
  entryComponents: [Profile9Page],
})
export class Profile9PageModule {
}
