import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Profile5Page } from './profile5.page';

describe('ProfilePage', () => {
  let component: Profile5Page;
  let fixture: ComponentFixture<Profile5Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Profile5Page ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Profile5Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
