import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { Profile5Page } from './profile5.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
  ],
  declarations: [Profile5Page],
  exports: [Profile5Page],
  entryComponents: [Profile5Page],
})
export class Profile5PageModule {
}
