import { Component, OnInit, ViewChild } from '@angular/core';
import { IonSlides} from '@ionic/angular';
import {PdfPage} from '../pdf/pdf.page';
import { Router } from '@angular/router';
@Component({
  selector: 'app-slides',
  templateUrl: './slides.page.html',
  styleUrls: ['./slides.page.scss'],
})
export class PagesPage implements OnInit {

  constructor(private router: Router) {
  }

  ngOnInit() {
  }
  hideMe: boolean = false
  @ViewChild(IonSlides) slides: IonSlides;
  public goToLast(): void {
    this.slides.slideTo(4, 0);
  }
  public next():void {
    this.slides.slideNext();
  }

  public prev():void {
    this.slides.slidePrev();
  }
  
  slideOptsOne = {
    initialSlide: 0,
    slidesPerView: 1,
    autoplay:true,pagination: {
      el: '.swiper-pagination',
      clickable: true,
     
    },
     navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },
  };
  disablePrevBtn = true;
  disableNextBtn = false;
  doCheck() {
    let prom1 = this.slides.isBeginning();
    let prom2 = this.slides.isEnd();
  
    Promise.all([prom1, prom2]).then((data) => {
      data[0] ? this.disablePrevBtn = true : this.disablePrevBtn = false;
      data[1] ? this.disableNextBtn = true : this.disableNextBtn = false;
    });
  }
  hide() {
    this.hideMe = true;
    
  }
 
 // play(){
     //  console.log("clicked");
      // this.router.navigateByUrl("/pdf");

    // }

    
}
