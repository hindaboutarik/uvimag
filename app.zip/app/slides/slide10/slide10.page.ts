import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-slide10',
  templateUrl: './slide10.page.html',
  styleUrls: ['./slide10.page.scss'],
})
export class Slide10Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
