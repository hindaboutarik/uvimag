import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Slide10Page } from './slide10.page';

describe('Slide10Page', () => {
  let component: Slide10Page;
  let fixture: ComponentFixture<Slide10Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Slide10Page ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Slide10Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
