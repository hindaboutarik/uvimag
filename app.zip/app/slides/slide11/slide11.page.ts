import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-slide11',
  templateUrl: './slide11.page.html',
  styleUrls: ['./slide11.page.scss'],
})
export class Slide11Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
