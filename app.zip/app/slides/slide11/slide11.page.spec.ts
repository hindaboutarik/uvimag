import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Slide11Page } from './slide11.page';

describe('Slide11Page', () => {
  let component: Slide11Page;
  let fixture: ComponentFixture<Slide11Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Slide11Page ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Slide11Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
