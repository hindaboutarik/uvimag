
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { Profile3Page } from './profile3.page';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: 'profile3',
    component: Profile3Page
  }
];
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
  ],
  declarations: [Profile3Page],
  exports: [Profile3Page],
  entryComponents: [Profile3Page],
})
export class Profile3PageModule {
}
