import { Component, OnInit, ViewChild } from '@angular/core';
import { IonSlides} from '@ionic/angular';
import { Router } from '@angular/router';
import { ModalController } from "@ionic/angular";
@Component({
  selector: 'app-slide1',
  templateUrl: './slide1.page.html',
  styleUrls: ['./slide1.page.scss'],
})
export class ContactsPage implements OnInit {

  contacts: any[] = [];
  constructor(private router: Router,private modalController:ModalController) {}

 
  ngOnInit() {
  
   
  }
  @ViewChild(IonSlides) slides: IonSlides;
  public goToLast(): void {
    this.slides.slideTo(4, 0);
  }
  public next():void {
    this.slides.slideNext();
  }

  public prev():void {
    this.slides.slidePrev();
  }
  
  slideOptsOne = {
    initialSlide: 0,
    slidesPerView: 1,
    pagination: {
      el: '.swiper-pagination',
      clickable: true,
     
    },
     navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },
  };
  disablePrevBtn = true;
  disableNextBtn = false;
  doCheck() {
    let prom1 = this.slides.isBeginning();
    let prom2 = this.slides.isEnd();
  
    Promise.all([prom1, prom2]).then((data) => {
      data[0] ? this.disablePrevBtn = true : this.disablePrevBtn = false;
      data[1] ? this.disableNextBtn = true : this.disableNextBtn = false;
    });
  }

}
