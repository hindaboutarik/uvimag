import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-slide7',
  templateUrl: './slide7.page.html',
  styleUrls: ['./slide7.page.scss'],
})
export class Slide7Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
