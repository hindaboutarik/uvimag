import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-slide5',
  templateUrl: './slide5.page.html',
  styleUrls: ['./slide5.page.scss'],
})
export class Slide5Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
