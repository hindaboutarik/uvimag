import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Slide5Page } from './slide5.page';

describe('Slide5Page', () => {
  let component: Slide5Page;
  let fixture: ComponentFixture<Slide5Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Slide5Page ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Slide5Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
