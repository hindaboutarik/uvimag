import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-slide6',
  templateUrl: './slide6.page.html',
  styleUrls: ['./slide6.page.scss'],
})
export class Slide6Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
