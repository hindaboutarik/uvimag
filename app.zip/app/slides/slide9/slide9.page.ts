import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-slide9',
  templateUrl: './slide9.page.html',
  styleUrls: ['./slide9.page.scss'],
})
export class Slide9Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
