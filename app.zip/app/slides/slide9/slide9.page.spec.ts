import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Slide9Page } from './slide9.page';

describe('Slide9Page', () => {
  let component: Slide9Page;
  let fixture: ComponentFixture<Slide9Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Slide9Page ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Slide9Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
