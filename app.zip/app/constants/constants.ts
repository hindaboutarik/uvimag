export const SWIPE_DIRECTION = {
    rightToLeft: 2,
    leftToRight: 1
  };